// Fonction pour gérer la recherche
function search() {
    const query = document.getElementById("search-input").value.trim();
    const resultsContainer = document.getElementById("results-container");

    // Vérifie si la recherche est vide
    if (query === "") {
        alert("Veuillez entrer un terme de recherche.");
        return;
    }

    // Efface les résultats précédents
    resultsContainer.innerHTML = "";

    // Récupérer les fichiers depuis l'API du serveur
    fetch('/files')
        .then(response => response.json())
        .then(data => {
            const filteredResults = [];

            // Parcours chaque fichier et filtre ceux qui contiennent la recherche
            data.forEach(file => {
                if (file.content.toLowerCase().includes(query.toLowerCase())) {
                    filteredResults.push(file);
                }
            });

            // Si aucun résultat n'est trouvé
            if (filteredResults.length === 0) {
                resultsContainer.innerHTML = "<p>Aucun résultat trouvé.</p>";
                return;
            }

            // Affiche les résultats filtrés
            filteredResults.forEach(file => {
                const resultItem = document.createElement("div");
                resultItem.classList.add("result-item");

                resultItem.innerHTML = `
                    <h4>${file.filename}</h4>
                    <p>${file.content.substring(0, 200)}...</p> <!-- Affiche un extrait de 200 caractères -->
                    <button onclick="showFullContent('${file.filename}')">Lire le fichier complet</button>
                `;

                resultsContainer.appendChild(resultItem);
            });
        })
        .catch(error => {
            console.error('Erreur lors de la récupération des fichiers:', error);
            resultsContainer.innerHTML = "<p>Une erreur est survenue lors de la récupération des fichiers.</p>";
        });
}

// Fonction pour afficher le contenu complet d'un fichier dans la modale
function showFullContent(filename) {
    fetch(`/files/${filename}`)
        .then(response => response.json())
        .then(file => {
            const modal = document.getElementById("file-modal");
            const modalTitle = document.getElementById("modal-title");
            const modalContent = document.getElementById("modal-content");

            modalTitle.textContent = file.filename;
            modalContent.textContent = file.content;

            // Affiche la modale
            modal.style.display = "block";

            // Ferme la modale lorsqu'on clique sur le bouton de fermeture
            document.querySelector(".close-btn").onclick = () => {
                modal.style.display = "none";
            };

            // Ferme la modale si l'utilisateur clique en dehors de la fenêtre modale
            window.onclick = (event) => {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            };
        })
        .catch(error => {
            console.error('Erreur lors de l\'ouverture du fichier complet:', error);
        });
}


// script.js

// Exemple de fonction pour afficher le popup
function showModal() {
    document.getElementById('file-modal').style.display = 'block';
    document.getElementById('modal-title').textContent = "Titre du popup";
    document.getElementById('modal-content').textContent = "Contenu du popup ici.";
}

// Exemple d'événement pour fermer le popup
document.querySelector('.close-btn').addEventListener('click', function() {
    document.getElementById('file-modal').style.display = 'none';
});
