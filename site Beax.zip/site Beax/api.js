const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3000;

// Servir les fichiers statiques
app.use(express.static(path.join(__dirname, 'public')));

app.get('/files', (req, res) => {
    const folderPath = path.join(__dirname, 'files');
    fs.readdir(folderPath, (err, files) => {
        if (err) {
            console.error("Erreur de lecture du dossier :", err);
            return res.status(500).json({ message: "Impossible de lire le dossier." });
        }

        const textFiles = files.filter(file => file.endsWith('.txt'));

        const fileContents = [];
        textFiles.forEach(file => {
            const content = fs.readFileSync(path.join(folderPath, file), 'utf8');
            fileContents.push({ filename: file, content });
        });

        // Log des fichiers détectés
        console.log("Fichiers détectés :", fileContents);

        res.json(fileContents);
    });
});

// Route pour récupérer un fichier spécifique
app.get('/files/:filename', (req, res) => {
    const folderPath = path.join(__dirname, 'files');
    const sanitizedFileName = req.params.filename.replace(/[^a-zA-Z0-9_.-]/g, '');
    const filePath = path.join(folderPath, sanitizedFileName);

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "Fichier non trouvé." });
    }

    fs.readFile(filePath, 'utf8', (err, content) => {
        if (err) {
            return res.status(500).json({ message: "Erreur lors de la lecture du fichier." });
        }

        res.json({ filename: sanitizedFileName, content });
    });
});

// Lancer le serveur
app.listen(port, () => {
    console.log(`Serveur démarré sur http://localhost:${port}`);
});
